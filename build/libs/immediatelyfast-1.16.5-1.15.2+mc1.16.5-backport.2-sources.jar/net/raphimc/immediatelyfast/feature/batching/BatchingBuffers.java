package net.raphimc.immediatelyfast.feature.batching;

import net.minecraft.class_1921;
import net.minecraft.class_287;
import net.minecraft.class_4597;
import net.raphimc.immediatelyfast.ImmediatelyFast;
import net.raphimc.immediatelyfast.feature.core.BatchableImmediate;

import java.util.LinkedHashMap;
import java.util.Map;

public final class BatchingBuffers {

    public static class_4597 FILL_CONSUMER;
    public static class_4597 TEXT_CONSUMER;

    private static final BatchableImmediate HUD_BATCH = new BatchableImmediate(createLayerBuffers(BatchingRenderLayers.GUI_FILL));

    private BatchingBuffers() {
    }

    public static void beginHudBatching() {
        ImmediatelyFast.loadConfig();
        if (!ImmediatelyFast.config.isHudBatchingEnabled() || !ImmediatelyFast.config.enhanced_batching) {
            return;
        }

        if (HUD_BATCH.hasActiveLayers()) {
            ImmediatelyFast.LOGGER.warn("HUD batching was already active. Closing the stale batch.");
            HUD_BATCH.close();
        }

        FILL_CONSUMER = HUD_BATCH;
        TEXT_CONSUMER = HUD_BATCH;
    }

    public static void endHudBatching() {
        if (FILL_CONSUMER == null && TEXT_CONSUMER == null) {
            return;
        }

        FILL_CONSUMER = null;
        TEXT_CONSUMER = null;
        HUD_BATCH.method_22993();
    }

    public static boolean isHudBatching() {
        return FILL_CONSUMER != null || TEXT_CONSUMER != null;
    }

    public static BatchableImmediate getHudBatch() {
        return HUD_BATCH;
    }

    public static Map<class_1921, class_287> createLayerBuffers(class_1921... layers) {
        final Map<class_1921, class_287> layerBuffers = new LinkedHashMap<>();
        for (class_1921 layer : layers) {
            layerBuffers.put(layer, new class_287(layer.method_22722()));
        }
        return layerBuffers;
    }

}
