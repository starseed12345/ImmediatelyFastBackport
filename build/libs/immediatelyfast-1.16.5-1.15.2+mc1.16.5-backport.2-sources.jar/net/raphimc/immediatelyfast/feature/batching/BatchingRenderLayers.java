package net.raphimc.immediatelyfast.feature.batching;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_1921;
import net.minecraft.class_290;

public final class BatchingRenderLayers {

    public static final class_1921 GUI_FILL = new ImmediatelyFastRenderLayer(
            "gui_fill",
            7,
            () -> {
                RenderSystem.enableBlend();
                RenderSystem.disableTexture();
                RenderSystem.defaultBlendFunc();
            },
            () -> {
                RenderSystem.enableTexture();
                RenderSystem.disableBlend();
            }
    );

    private BatchingRenderLayers() {
    }

    private static final class ImmediatelyFastRenderLayer extends class_1921 {

        private ImmediatelyFastRenderLayer(String name, int drawMode, Runnable startAction, Runnable endAction) {
            super("immediatelyfast_" + name, class_290.field_1576, drawMode, 2048, false, true, startAction, endAction);
        }

    }

}
