package net.raphimc.immediatelyfast.feature.map_atlas_generation;

import net.minecraft.class_1043;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.raphimc.immediatelyfast.ImmediatelyFast;

public final class MapAtlasTexture implements AutoCloseable {

    public static final int MAP_SIZE = 128;

    private final int id;
    private final int atlasSize;
    private final int mapsPerAtlas;
    private final class_2960 identifier;
    private final class_1043 texture;
    private int mapCount;

    public MapAtlasTexture(int id) {
        this.id = id;
        ImmediatelyFast.loadConfig();
        this.atlasSize = Math.max(MAP_SIZE, ImmediatelyFast.config.map_atlas_size);
        this.mapsPerAtlas = (this.atlasSize / MAP_SIZE) * (this.atlasSize / MAP_SIZE);
        this.identifier = new class_2960("immediatelyfast", "map_atlas/" + id);
        this.texture = new class_1043(this.atlasSize, this.atlasSize, true);
        class_310.method_1551().method_1531().method_4616(this.identifier, this.texture);
    }

    public int getNextMapLocation() {
        if (this.mapCount >= this.mapsPerAtlas) {
            return -1;
        }

        final int atlasX = this.mapCount % (this.atlasSize / MAP_SIZE);
        final int atlasY = this.mapCount / (this.atlasSize / MAP_SIZE);
        this.mapCount++;
        return (this.id << 16) | (atlasX << 8) | atlasY;
    }

    public int getId() {
        return this.id;
    }

    public class_2960 getIdentifier() {
        return this.identifier;
    }

    public int getAtlasSize() {
        return this.atlasSize;
    }

    public class_1043 getTexture() {
        return this.texture;
    }

    @Override
    public void close() {
        this.texture.close();
        class_310.method_1551().method_1531().method_4615(this.identifier);
    }

}
