package net.raphimc.immediatelyfast.feature.core;

import it.unimi.dsi.fastutil.objects.ReferenceArraySet;
import net.minecraft.class_287;
import net.raphimc.immediatelyfast.injection.interfaces.IBufferBuilder;
import org.apache.commons.lang3.tuple.MutablePair;
import org.apache.commons.lang3.tuple.Pair;

import java.util.Set;

public final class BufferBuilderPool {

    private static final Set<Pair<class_287, Long>> POOL = new ReferenceArraySet<>(256);
    private static long lastCleanup;

    private BufferBuilderPool() {
    }

    public static class_287 get() {
        if (lastCleanup < System.currentTimeMillis() - 5_000L) {
            lastCleanup = System.currentTimeMillis();
            cleanup();
        }

        for (Pair<class_287, Long> entry : POOL) {
            final class_287 bufferBuilder = entry.getKey();
            if (!bufferBuilder.method_22893() && !((IBufferBuilder) bufferBuilder).immediatelyfast$isReleased()) {
                entry.setValue(System.currentTimeMillis());
                return bufferBuilder;
            }
        }

        final class_287 bufferBuilder = new class_287(256);
        POOL.add(new MutablePair<class_287, Long>(bufferBuilder, System.currentTimeMillis()));
        return bufferBuilder;
    }

    public static int getAllocatedSize() {
        cleanup();
        return POOL.size();
    }

    public static void onEndFrame() {
        cleanup();
    }

    private static void cleanup() {
        POOL.removeIf(entry -> ((IBufferBuilder) entry.getKey()).immediatelyfast$isReleased());
        POOL.removeIf(entry -> {
            if (entry.getValue() < System.currentTimeMillis() - 120_000L) {
                ((IBufferBuilder) entry.getKey()).immediatelyfast$release();
                return true;
            }
            return false;
        });
    }

}
