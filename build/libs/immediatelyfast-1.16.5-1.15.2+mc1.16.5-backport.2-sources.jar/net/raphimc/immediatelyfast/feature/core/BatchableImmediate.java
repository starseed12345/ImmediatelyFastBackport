package net.raphimc.immediatelyfast.feature.core;

import java.util.Map;
import net.minecraft.class_1921;
import net.minecraft.class_287;

public class BatchableImmediate extends ImmediateAdapter {

    public BatchableImmediate() {
    }

    public BatchableImmediate(Map<class_1921, class_287> layerBuffers) {
        super(layerBuffers);
    }

    @Override
    protected void drawLayer(class_1921 layer) {
        for (class_287 bufferBuilder : this.getBufferBuilder(layer)) {
            if (bufferBuilder != null && bufferBuilder.method_22893()) {
                layer.method_23012(bufferBuilder, 0, 0, 0);
            }
        }
    }

}
