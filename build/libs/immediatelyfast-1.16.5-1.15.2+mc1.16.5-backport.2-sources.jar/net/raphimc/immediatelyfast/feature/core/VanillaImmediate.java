package net.raphimc.immediatelyfast.feature.core;

import java.util.Map;
import net.minecraft.class_1921;
import net.minecraft.class_287;
import net.minecraft.class_4597;

public final class VanillaImmediate extends class_4597.class_4598 {

    public VanillaImmediate(class_287 fallbackBuffer, Map<class_1921, class_287> layerBuffers) {
        super(fallbackBuffer, layerBuffers);
    }

}
