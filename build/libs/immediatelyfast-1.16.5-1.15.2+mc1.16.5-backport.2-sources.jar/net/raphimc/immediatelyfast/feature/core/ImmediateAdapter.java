package net.raphimc.immediatelyfast.feature.core;

import com.google.common.collect.ImmutableMap;
import it.unimi.dsi.fastutil.objects.Reference2ObjectLinkedOpenHashMap;
import it.unimi.dsi.fastutil.objects.Reference2ObjectMap;
import it.unimi.dsi.fastutil.objects.ReferenceLinkedOpenHashSet;
import it.unimi.dsi.fastutil.objects.ReferenceSet;
import net.minecraft.class_1921;
import net.minecraft.class_287;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.raphimc.immediatelyfast.ImmediatelyFast;

import java.util.Collections;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

public abstract class ImmediateAdapter extends class_4597.class_4598 implements AutoCloseable {

    private static final class_287 FALLBACK_BUFFER = new class_287(0);

    protected final Reference2ObjectMap<class_1921, class_287> fallbackBuffers = new Reference2ObjectLinkedOpenHashMap<>();
    protected final ReferenceSet<class_1921> activeLayers = new ReferenceLinkedOpenHashSet<>();
    private boolean drawFallbackLayersFirst;

    public ImmediateAdapter() {
        this(ImmutableMap.of());
    }

    public ImmediateAdapter(Map<class_1921, class_287> layerBuffers) {
        super(FALLBACK_BUFFER, layerBuffers);
    }

    @Override
    public class_4588 getBuffer(class_1921 layer) {
        final Optional<class_1921> newLayer = layer.method_24296();
        if (!this.drawFallbackLayersFirst && !this.field_20954.equals(newLayer) && this.field_20954.isPresent() && !this.field_20953.containsKey(this.field_20954.get())) {
            this.drawFallbackLayersFirst = true;
        }
        this.field_20954 = newLayer;

        final class_287 bufferBuilder = this.getOrCreateBufferBuilder(layer);
        if (!bufferBuilder.method_22893()) {
            bufferBuilder.method_1328(layer.method_23033(), layer.method_23031());
        }
        if (ImmediatelyFast.config.debug_only_use_last_usage_for_batch_ordering && this.activeLayers.contains(layer)) {
            this.activeLayers.remove(layer);
            this.activeLayers.add(layer);
        } else {
            this.activeLayers.add(layer);
        }
        return bufferBuilder;
    }

    @Override
    public void method_22993() {
        if (this.activeLayers.isEmpty()) {
            this.close();
            return;
        }

        this.drawCurrentLayer();
        for (class_1921 layer : this.field_20953.keySet()) {
            this.method_22994(layer);
        }
    }

    @Override
    public void method_22994(class_1921 layer) {
        if (this.drawFallbackLayersFirst) {
            this.drawCurrentLayer();
        }

        this.activeLayers.remove(layer);
        this.drawLayer(layer);
        this.fallbackBuffers.remove(layer);

        if (this.field_20954.equals(layer.method_24296())) {
            this.field_20954 = Optional.empty();
        }
    }

    @Override
    public void close() {
        this.field_20954 = Optional.empty();
        this.drawFallbackLayersFirst = false;

        for (class_1921 layer : this.activeLayers) {
            for (class_287 bufferBuilder : this.getBufferBuilder(layer)) {
                if (bufferBuilder.method_22893()) {
                    bufferBuilder.method_1326();
                    bufferBuilder.method_1343();
                }
            }
        }

        this.activeLayers.clear();
        this.fallbackBuffers.clear();
    }

    public boolean hasActiveLayers() {
        return !this.activeLayers.isEmpty();
    }

    protected abstract void drawLayer(class_1921 layer);

    protected void drawCurrentLayer() {
        this.field_20954 = Optional.empty();
        this.drawFallbackLayersFirst = false;

        for (class_1921 layer : this.activeLayers.toArray(new class_1921[0])) {
            if (!this.field_20953.containsKey(layer)) {
                this.method_22994(layer);
            }
        }
    }

    protected class_287 getOrCreateBufferBuilder(class_1921 layer) {
        if (this.field_20953.containsKey(layer)) {
            return this.field_20953.get(layer);
        }

        class_287 bufferBuilder = this.fallbackBuffers.get(layer);
        if (bufferBuilder == null) {
            bufferBuilder = BufferBuilderPool.get();
            this.fallbackBuffers.put(layer, bufferBuilder);
        }
        return bufferBuilder;
    }

    protected Set<class_287> getBufferBuilder(class_1921 layer) {
        if (this.fallbackBuffers.containsKey(layer)) {
            return Collections.singleton(this.fallbackBuffers.get(layer));
        }
        if (this.field_20953.containsKey(layer)) {
            return Collections.singleton(this.field_20953.get(layer));
        }
        return Collections.emptySet();
    }

}
