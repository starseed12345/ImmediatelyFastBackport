package net.raphimc.immediatelyfast.injection.mixins.fast_text_lookup;

import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_377;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_327.class)
public interface TextRendererAccess {

    @Invoker("getFontStorage")
    class_377 immediatelyfast$getFontStorage(class_2960 id);

}
