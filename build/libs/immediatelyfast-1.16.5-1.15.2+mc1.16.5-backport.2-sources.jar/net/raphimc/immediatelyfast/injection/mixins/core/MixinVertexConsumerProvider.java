package net.raphimc.immediatelyfast.injection.mixins.core;

import net.minecraft.class_1921;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_4597;
import net.raphimc.immediatelyfast.ImmediatelyFast;
import net.raphimc.immediatelyfast.feature.core.BatchableImmediate;
import net.raphimc.immediatelyfast.feature.core.VanillaImmediate;
import net.raphimc.immediatelyfast.injection.interfaces.IBufferBuilder;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

import java.util.Map;

@Mixin(class_4597.class)
public interface MixinVertexConsumerProvider {

    /**
     * @author RK_01, backported for 1.16.5
     * @reason Universal immediate mode batching
     */
    @Overwrite
    static class_4597.class_4598 immediate(Map<class_1921, class_287> layerBuffers, class_287 fallbackBuffer) {
        ImmediatelyFast.loadConfig();
        if (!ImmediatelyFast.config.enhanced_batching || ImmediatelyFast.config.debug_only_and_not_recommended_disable_universal_batching || fallbackBuffer == null) {
            if (fallbackBuffer == null) {
                fallbackBuffer = class_289.method_1348().method_1349();
            }
            return new VanillaImmediate(fallbackBuffer, layerBuffers);
        }

        if (fallbackBuffer != class_289.method_1348().method_1349()) {
            ((IBufferBuilder) fallbackBuffer).immediatelyfast$release();
        }
        return new BatchableImmediate(layerBuffers);
    }

}
