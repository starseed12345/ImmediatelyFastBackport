package net.raphimc.immediatelyfast.injection.mixins.fast_text_lookup;

import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_377;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(targets = "net.minecraft.client.font.TextRenderer$Drawer")
public abstract class MixinTextRendererDrawer {

    @Unique
    private class_2960 immediatelyfast$lastFontId;

    @Unique
    private class_377 immediatelyfast$lastFontStorage;

    @Unique
    private class_1921 immediatelyfast$lastRenderLayer;

    @Unique
    private class_4588 immediatelyfast$lastVertexConsumer;

    @Redirect(method = "accept", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/font/TextRenderer;method_27519(Lnet/minecraft/client/font/TextRenderer;Lnet/minecraft/util/Identifier;)Lnet/minecraft/client/font/FontStorage;"))
    private class_377 immediatelyfast$cacheFontStorage(class_327 textRenderer, class_2960 fontId) {
        if (fontId.equals(this.immediatelyfast$lastFontId) && this.immediatelyfast$lastFontStorage != null) {
            return this.immediatelyfast$lastFontStorage;
        }

        this.immediatelyfast$lastFontId = fontId;
        this.immediatelyfast$lastFontStorage = ((TextRendererAccess) textRenderer).immediatelyfast$getFontStorage(fontId);
        return this.immediatelyfast$lastFontStorage;
    }

    @Redirect(method = "accept", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/VertexConsumerProvider;getBuffer(Lnet/minecraft/client/render/RenderLayer;)Lnet/minecraft/client/render/VertexConsumer;"))
    private class_4588 immediatelyfast$cacheVertexConsumer(class_4597 vertexConsumers, class_1921 renderLayer) {
        if (this.immediatelyfast$lastRenderLayer == renderLayer && this.immediatelyfast$lastVertexConsumer != null) {
            return this.immediatelyfast$lastVertexConsumer;
        }

        this.immediatelyfast$lastRenderLayer = renderLayer;
        this.immediatelyfast$lastVertexConsumer = vertexConsumers.getBuffer(renderLayer);
        return this.immediatelyfast$lastVertexConsumer;
    }

}
