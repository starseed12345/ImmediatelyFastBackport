package net.raphimc.immediatelyfast.injection.mixins.hud_batching;

import net.minecraft.class_287;
import net.minecraft.class_327;
import net.minecraft.class_4597;
import net.raphimc.immediatelyfast.feature.batching.BatchingBuffers;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_327.class)
public abstract class MixinTextRenderer {

    @Redirect(
            method = {
                    "draw(Ljava/lang/String;FFILnet/minecraft/util/math/Matrix4f;ZZ)I",
                    "draw(Lnet/minecraft/text/OrderedText;FFILnet/minecraft/util/math/Matrix4f;Z)I"
            },
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/VertexConsumerProvider;immediate(Lnet/minecraft/client/render/BufferBuilder;)Lnet/minecraft/client/render/VertexConsumerProvider$Immediate;")
    )
    private class_4597.class_4598 immediatelyfast$useHudTextBatch(class_287 fallbackBuffer) {
        if (BatchingBuffers.TEXT_CONSUMER instanceof class_4597.class_4598) {
            return (class_4597.class_4598) BatchingBuffers.TEXT_CONSUMER;
        }
        return class_4597.method_22991(fallbackBuffer);
    }

    @Redirect(
            method = {
                    "draw(Ljava/lang/String;FFILnet/minecraft/util/math/Matrix4f;ZZ)I",
                    "draw(Lnet/minecraft/text/OrderedText;FFILnet/minecraft/util/math/Matrix4f;Z)I"
            },
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/VertexConsumerProvider$Immediate;draw()V")
    )
    private void immediatelyfast$deferHudTextDraw(class_4597.class_4598 immediate) {
        if (immediate != BatchingBuffers.getHudBatch()) {
            immediate.method_22993();
        }
    }

}
