package net.raphimc.immediatelyfast.injection.mixins.map_atlas_generation;

import net.raphimc.immediatelyfast.ImmediatelyFast;
import net.raphimc.immediatelyfast.feature.map_atlas_generation.MapAtlasTexture;
import net.raphimc.immediatelyfast.injection.interfaces.IMapRenderer;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.Slice;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static net.raphimc.immediatelyfast.feature.map_atlas_generation.MapAtlasTexture.MAP_SIZE;

import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_1060;
import net.minecraft.class_22;
import net.minecraft.class_2960;
import net.minecraft.class_330;
import net.minecraft.class_3620;
import net.minecraft.class_4588;

@Mixin(targets = "net.minecraft.client.render.MapRenderer$MapTexture", priority = 1100)
public abstract class MixinMapRendererMapTexture {

    @Shadow
    @Final
    private class_22 mapState;

    @Mutable
    @Shadow
    @Final
    private class_1043 texture;

    @Unique
    private int immediatelyfast$atlasX;

    @Unique
    private int immediatelyfast$atlasY;

    @Unique
    private MapAtlasTexture immediatelyfast$atlasTexture;

    @Inject(method = "<init>", at = @At(value = "INVOKE", target = "Ljava/lang/Object;<init>()V", shift = At.Shift.AFTER, remap = false))
    private void immediatelyfast$initAtlasParameters(class_330 mapRenderer, class_22 state, CallbackInfo ci) {
        final int packedLocation = ((IMapRenderer) mapRenderer).immediatelyfast$getAtlasMapping(state.method_76());
        if (packedLocation == -1) {
            ImmediatelyFast.LOGGER.warn("Map " + state.method_76() + " is not in an atlas");
            return;
        }

        this.immediatelyfast$atlasX = ((packedLocation >> 8) & 255) * MAP_SIZE;
        this.immediatelyfast$atlasY = (packedLocation & 255) * MAP_SIZE;
        this.immediatelyfast$atlasTexture = ((IMapRenderer) mapRenderer).immediatelyfast$getMapAtlasTexture(packedLocation >> 16);
    }

    @Redirect(method = "<init>", at = @At(value = "NEW", target = "(IIZ)Lnet/minecraft/client/texture/NativeImageBackedTexture;"))
    private class_1043 immediatelyfast$dontAllocateTexture(int width, int height, boolean useMipmaps) {
        if (this.immediatelyfast$atlasTexture != null) {
            return new class_1043(1, 1, false);
        }
        return new class_1043(width, height, useMipmaps);
    }

    @Redirect(method = "<init>", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/texture/TextureManager;registerDynamicTexture(Ljava/lang/String;Lnet/minecraft/client/texture/NativeImageBackedTexture;)Lnet/minecraft/util/Identifier;"))
    private class_2960 immediatelyfast$getAtlasTextureIdentifier(class_1060 textureManager, String id, class_1043 texture) {
        if (this.immediatelyfast$atlasTexture != null) {
            texture.close();
            this.texture = null;
            return this.immediatelyfast$atlasTexture.getIdentifier();
        }
        return textureManager.method_4617(id, texture);
    }

    @Inject(method = "updateTexture", at = @At("HEAD"), cancellable = true)
    private void immediatelyfast$updateAtlasTexture(CallbackInfo ci) {
        if (this.immediatelyfast$atlasTexture == null) {
            return;
        }

        ci.cancel();
        final class_1043 atlasTexture = this.immediatelyfast$atlasTexture.getTexture();
        final class_1011 atlasImage = atlasTexture.method_4525();
        if (atlasImage == null) {
            throw new IllegalStateException("Atlas texture has already been closed");
        }

        for (int y = 0; y < MAP_SIZE; y++) {
            for (int x = 0; x < MAP_SIZE; x++) {
                final int i = x + y * MAP_SIZE;
                final int color = this.mapState.field_122[i] & 255;
                if (color / 4 == 0) {
                    atlasImage.method_4305(this.immediatelyfast$atlasX + x, this.immediatelyfast$atlasY + y, 0);
                } else {
                    atlasImage.method_4305(this.immediatelyfast$atlasX + x, this.immediatelyfast$atlasY + y, class_3620.field_16006[color / 4].method_15820(color & 3));
                }
            }
        }

        atlasTexture.method_23207();
        atlasImage.method_4312(0, this.immediatelyfast$atlasX, this.immediatelyfast$atlasY, this.immediatelyfast$atlasX, this.immediatelyfast$atlasY, MAP_SIZE, MAP_SIZE, false, false);
    }

    @Redirect(
            method = "draw",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/VertexConsumer;texture(FF)Lnet/minecraft/client/render/VertexConsumer;"),
            slice = @Slice(
                    from = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/VertexConsumer;vertex(Lnet/minecraft/util/math/Matrix4f;FFF)Lnet/minecraft/client/render/VertexConsumer;", ordinal = 0),
                    to = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/VertexConsumer;next()V", ordinal = 3)
            )
    )
    private class_4588 immediatelyfast$drawAtlasTexture(class_4588 instance, float u, float v) {
        if (this.immediatelyfast$atlasTexture != null) {
            final int atlasSize = this.immediatelyfast$atlasTexture.getAtlasSize();
            if (u == 0F && v == 1F) {
                u = (float) this.immediatelyfast$atlasX / atlasSize;
                v = (float) (this.immediatelyfast$atlasY + MAP_SIZE) / atlasSize;
            } else if (u == 1F && v == 1F) {
                u = (float) (this.immediatelyfast$atlasX + MAP_SIZE) / atlasSize;
                v = (float) (this.immediatelyfast$atlasY + MAP_SIZE) / atlasSize;
            } else if (u == 1F && v == 0F) {
                u = (float) (this.immediatelyfast$atlasX + MAP_SIZE) / atlasSize;
                v = (float) this.immediatelyfast$atlasY / atlasSize;
            } else if (u == 0F && v == 0F) {
                u = (float) this.immediatelyfast$atlasX / atlasSize;
                v = (float) this.immediatelyfast$atlasY / atlasSize;
            }
        }

        return instance.method_22913(u, v);
    }

    @Inject(method = "close", at = @At("HEAD"), cancellable = true)
    private void immediatelyfast$dontCloseAtlasTexture(CallbackInfo ci) {
        if (this.immediatelyfast$atlasTexture != null) {
            ci.cancel();
        }
    }

}
