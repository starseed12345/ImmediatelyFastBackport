package net.raphimc.immediatelyfast.injection.mixins.hud_batching;

import net.minecraft.class_329;
import net.minecraft.class_4587;
import net.raphimc.immediatelyfast.feature.batching.BatchingBuffers;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_329.class)
public abstract class MixinInGameHud {

    @Inject(method = "render", at = @At("HEAD"))
    private void immediatelyfast$beginHudBatching(class_4587 matrices, float tickDelta, CallbackInfo ci) {
        BatchingBuffers.beginHudBatching();
    }

    @Inject(method = "render", at = @At("RETURN"))
    private void immediatelyfast$endHudBatching(class_4587 matrices, float tickDelta, CallbackInfo ci) {
        BatchingBuffers.endHudBatching();
    }

}
