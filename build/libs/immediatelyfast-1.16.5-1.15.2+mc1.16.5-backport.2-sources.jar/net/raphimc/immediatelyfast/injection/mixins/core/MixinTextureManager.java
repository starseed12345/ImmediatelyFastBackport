package net.raphimc.immediatelyfast.injection.mixins.core;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Map;
import net.minecraft.class_1044;
import net.minecraft.class_1060;
import net.minecraft.class_2960;

@Mixin(class_1060.class)
public abstract class MixinTextureManager {

    @Shadow
    @Final
    private Map<class_2960, class_1044> textures;

    @Inject(method = "destroyTexture", at = @At("RETURN"))
    private void immediatelyfast$removeDestroyedTexture(class_2960 id, CallbackInfo ci) {
        this.textures.remove(id);
    }

}
