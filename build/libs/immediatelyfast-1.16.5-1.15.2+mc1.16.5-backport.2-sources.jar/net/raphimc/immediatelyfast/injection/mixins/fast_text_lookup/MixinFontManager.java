package net.raphimc.immediatelyfast.injection.mixins.fast_text_lookup;

import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Map;
import java.util.function.Function;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_377;
import net.minecraft.class_378;

@Mixin(value = class_378.class, priority = 500)
public abstract class MixinFontManager {

    @Shadow
    @Final
    private Map<class_2960, class_377> fontStorages;

    @Shadow
    private Map<class_2960, class_2960> idOverrides;

    @Shadow
    protected abstract class_377 method_27542(class_2960 id);

    @Unique
    private final Map<class_2960, class_377> immediatelyfast$overriddenFontStorages = new Object2ObjectOpenHashMap<>();

    @Unique
    private class_377 immediatelyfast$defaultFontStorage;

    @Unique
    private class_377 immediatelyfast$unicodeFontStorage;

    @Inject(method = "setIdOverrides", at = @At("RETURN"))
    private void immediatelyfast$rebuildOverriddenFontStoragesOnChange(CallbackInfo ci) {
        this.immediatelyfast$rebuildOverriddenFontStorages();
    }

    @ModifyArg(method = "createTextRenderer", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/font/TextRenderer;<init>(Ljava/util/function/Function;)V"))
    private Function<class_2960, class_377> immediatelyfast$overrideFontStorage(Function<class_2960, class_377> original) {
        this.immediatelyfast$rebuildOverriddenFontStorages();
        return id -> {
            if (class_310.field_1740.equals(id) && this.immediatelyfast$defaultFontStorage != null) {
                return this.immediatelyfast$defaultFontStorage;
            }
            if (class_310.field_24211.equals(id) && this.immediatelyfast$unicodeFontStorage != null) {
                return this.immediatelyfast$unicodeFontStorage;
            }

            final class_377 storage = this.immediatelyfast$overriddenFontStorages.get(id);
            if (storage != null) {
                return storage;
            }

            return original.apply(id);
        };
    }

    @Unique
    private void immediatelyfast$rebuildOverriddenFontStorages() {
        this.immediatelyfast$overriddenFontStorages.clear();
        this.immediatelyfast$overriddenFontStorages.putAll(this.fontStorages);
        for (class_2960 key : this.idOverrides.keySet()) {
            this.immediatelyfast$overriddenFontStorages.put(key, this.method_27542(key));
        }

        this.immediatelyfast$defaultFontStorage = this.immediatelyfast$overriddenFontStorages.get(class_310.field_1740);
        this.immediatelyfast$unicodeFontStorage = this.immediatelyfast$overriddenFontStorages.get(class_310.field_24211);
    }

}
